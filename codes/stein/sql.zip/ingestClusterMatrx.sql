LOAD DATA LOCAL INFILE '/tmp/a.txt' INTO TABLE Cluster.Matrx;
