#
# libraries needed
library(RMySQL)
library(readr)
library(stringr)
library(ggplot2)
library(scales)
library(dplyr)

# --- defaults ---
Species = 'Si'
Moment = 'avg'
minDate='"2001-01-01"'
maxDate='"2002-01-31"'


# --- read preformatted SQL query from file---
query = read_file("../_fluxes_vs_day.sql")
print(query)

# --- manipulate SQL, insert variables ---

query <- str_replace_all(query, '@minDate',minDate)
query <- str_replace_all(query, '@maxDate',maxDate)
query <- str_replace_all(query, '@mom',Moment)
query <- str_replace_all(query, '@i',Species)

query <- str_replace_all(query, '@minX','-25')
query <- str_replace_all(query, '@maxX','0')

query <- str_replace_all(query, '@minY','-15')
query <- str_replace_all(query, '@maxY','15')

query <- str_replace_all(query, '@minZ','-15')
query <- str_replace_all(query, '@maxZ','15')

print(query)


# -- connect to DB, send query ---

conn <- dbConnect(MySQL(), user='seh', password='', dbname='Cluster', host='127.0.0.1',port=3309)
result = dbSendQuery(conn, query)
intensity = fetch(result, n=-1)
dbDisconnect(conn)

intensity <- filter(intensity, Intensity > 0.1)
intensity <- filter(intensity, Intensity < 2)
# --- plotting ---

p <- ggplot(data=intensity, mapping=aes(x=as.Date(DateTime,format="%Y-%m-%d"), y=Intensity, group=1, color=as.factor(SCid)) ) +
#	geom_line(size=1) + 
	geom_point(size=3, alpha=0.7) +
	geom_smooth(method="lm",formula=y ~poly(x,4), se=FALSE,size=0.4,) +
	geom_errorbar(aes(ymin=Intensity-StdDev, ymax=Intensity+StdDev)) +
	labs(title ='Si intensity for the 4 Cluster spacecraft', x='Date', y='Intensity',color="SC no.") +
	scale_x_date(date_breaks='1 years',labels=date_format("%b-%y")) +
	scale_color_manual(values=c("black","red","green","blue")) +
	facet_wrap(~as.factor(SCid)) +
	theme_bw()



h <- ggplot(data=intensity, mapping=aes(x=Intensity, group=1, color=as.factor(SCid))) +
	geom_histogram(binwidth=0.05) +
	geom_density(alpha=0.5, fill="white") +
	geom_vline(aes(xintercept=mean(Intensity)),color='blue') 



show(p)

