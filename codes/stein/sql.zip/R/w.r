
#
library(ggplot2)
library(readr)


data <- read.csv("w1.csv",header=TRUE,sep="\t");

fixed <- mutate(data, weight = ifelse(wm<900,(1000+wm)/10,wm/10))

w <- ggplot(data=fixed,aes(x=as.Date(dt,format="%d.%m.%Y"),y=weight),color=weight)+
	geom_point() +
	labs (
		title = "Weight", y="Weight",x="Date"
	)

show(w)


