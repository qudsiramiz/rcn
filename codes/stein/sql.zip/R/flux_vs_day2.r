#
# libraries needed
library(RMySQL)
library(readr)
library(stringr)
library(ggplot2)

# --- defaults ---
Species = 'Fe'
Moment = 'avg'
minDate='"2006-01-01"'
maxDate='"2006-06-31"'


# --- read preformatted SQL query from file---
query = read_file("../_fluxes_vs_day.sql")
print(query)

# --- manipulate SQL, insert variables ---

query <- str_replace_all(query, '@minDate',minDate)
query <- str_replace_all(query, '@maxDate',maxDate)
query <- str_replace_all(query, '@mom',Moment)
query <- str_replace_all(query, '@i',Species)

query <- str_replace_all(query, '@minX','-25')
query <- str_replace_all(query, '@maxX','0')

query <- str_replace_all(query, '@minY','-15')
query <- str_replace_all(query, '@maxY','15')

query <- str_replace_all(query, '@minZ','-15')
query <- str_replace_all(query, '@maxZ','15')

print(query)


# -- connect to DB, send query ---

conn = dbConnect(MySQL(), user='seh', password='', dbname='Cluster', host='127.0.0.1',port=3309)
result = dbSendQuery(conn, query)
intensity = fetch(result, n=-1)
dbDisconnect(conn)



# --- plotting ---

ggplot(data=intensity) + 
  geom_point(mapping=aes(x=DateTime, y=Intensity, size=Intensity)) 


print(intensity)

