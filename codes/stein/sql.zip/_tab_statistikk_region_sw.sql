#
#  --- Generate table 1 in paper - Solar Wind settings 
#

set @minX=0;
set @maxX=25;

set @minY=-25;
set @maxY=25;

set @minZ=-25;
set @maxZ=25;

set @minR=13;
set @maxR=25;

set @minLat=00;
set @maxLat=99;


source _tab_statistikk_region.sql;

# --- write formatted output to table; Locale fr_CH ensures XXXX,xx format
select 
   concat('%% SW   : ',@dr," Counts =",@cr," R=",@rr," X=",@xr," Y=",@yr," Z=",@zr," Lat=",@lr) as ''
;

select 
   'Solar wind          & Outside static model  &' as '',
   format(@TotHr,0,'en_US') as '', 
   '     &   ' as '',
   format(100*@SiHr/@TotHr,1,'en_US') as '',
   '     &   ' as '',
#   format(@SiO,3,'en_US') as '',
#   '     &   ' as '',
   format(100*@FeHr/@TotHr,1,'en_US') as '',
#   '     &   ' as '',
#   format(@FeO,3,'en_US') as '',
   ' \\' as ''
;
