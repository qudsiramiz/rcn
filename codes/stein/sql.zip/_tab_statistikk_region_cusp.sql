#
#  --- Generate table 1 in paper CUSP
#
#
#  -- mysql -N to suppress headers
#

set @minX=-25;
set @maxX=25;

set @minY=-25;
set @maxY=25;

set @minZ=-25;
set @maxZ=25;

set @minR=0;
set @maxR=25;

set @minLat=60;
set @maxLat=99;


# ----- Cusp polar cp high lat --- 


source _tab_statistikk_region.sql;

# --- write formatted output to table; Locale fr_CH ensures XXXX,xx format
select 
   concat('%% Cusp : ',@dr," Counts =",@cr," R=",@rr," X=",@xr," Y=",@yr," Z=",@zr," Lat=",@lr) as ''
;

select 
   'High latitudes,     & Poleward of 60$^o$    &' as '',
   format(@TotHr,0,'en_US') as '', 
   '     &   ' as '',
   format(100*@SiHr/@TotHr,1,'en_US') as '',
   '     &   ' as '',
#   format(@SiO,3,'en_US') as '',
#   '     &   ' as '',
   format(100*@FeHr/@TotHr,1,'en_US') as '',
#   '     &   ' as '',
#   format(@FeO,3,'en_US') as '',
   ' \\' as ''
;


