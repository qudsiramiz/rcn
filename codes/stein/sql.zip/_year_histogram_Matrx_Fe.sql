#
#
#
#
SELECT 
   year(DateTime),count(*) 
FROM 
   Cluster.Matrx
WHERE
   (Fe1+Fe2+Fe3+Fe4+Fe5+Fe6+Fe7+Fe8) > 0.15 AND 
   (SCid=2 OR SCid=4) AND
   1=1
GROUP BY 
   year(DateTime)
;
