#
#
#
#
SELECT 
   year(DateTime),count(*) 
FROM 
   Cluster.Matrx
WHERE
#   SCID = @SCID AND
#   Si1 > 0 AND
   (Si1+Si2+Si3+Si4+Si5+Si6+Si7+Si8) > 0.15 AND 
   (SCid=2 OR SCid=4) AND
   1=1
GROUP BY 
   year(DateTime)
;
