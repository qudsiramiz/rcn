
select 
   year(DateTime)+month(DateTime)/12,
#   year(DateTime)+dayofyear(DateTime)/365,
#   year(DateTime)+week(DateTime,1)/53,
   median(F107),
   min(DST)
from 
   ACE.OMNI_1hr
where
   DateTime > '2001-01-01%' AND
   DST < 1000
group by 
   year(DateTime)+month(DateTime)/12
#   year(DateTime)+dayofyear(DateTime)/365
#   year(DateTime)+week(DateTime,1)/53
;
