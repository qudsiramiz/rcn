#
#  --- Generate table 1 in paper PS
#
#  --- GSM csys can be used since no constraits for SW
#  
#  Usage: 
#    mysql -N < tab_statistikk.sql | sed -e 's/citeA/\\citeA/g' -e 's/<=/\\le/g' -e 's/>=/\\ge/g' > ../Pap/tab_region.tex
#
#
select concat('%% Query date : ',curdate(),' ',curtime()) as '';
source _tab_statistikk_region_sw.sql;
select '                    & by \citeA{fair71a} \\' as '';
select '\\' as '';
#
#
source _tab_statistikk_region_cusp.sql;
select 'polar cap and cusp  & latitude \\' as '';
select '\\' as '';
#
#
source _tab_statistikk_region_lobe.sql;
select '                    & $|Y|_{GSM} <=$ 15Re  \\' as '';
select '                    & $|Z|_{GSM} >=$ 4 Re   \\' as '';
select '\\' as '';
#
#
source _tab_statistikk_region_ps.sql;
select '                    & $|Y|_{GSM} <=$ 15Re   \\' as '';
select '                    & $|Z|_{GSM} <=$ 4 Re   \\' as '';
select '\\' as '';
#
#
source _tab_statistikk_region_inner.sql;
select '                    & radial distance       \\' as '';
select '\\' as '';
#
#
source _tab_statistikk_region_all.sql;
select 'coverage            & time 2001-2020 [h]     \\' as '';
#
#

