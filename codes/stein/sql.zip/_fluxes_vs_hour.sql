#
# For Yama project get daily fluxes of Fe or Si
#

SELECT 
   hour(DateTime) as DateTime,
   @mom(@i1) as Intensity,
   stddev(@i1) as StdDev,
   SCId as SCid
FROM
   Cluster.Matrx
WHERE
   X BETWEEN @minX AND @maxX AND
   Y BETWEEN @minY AND @maxY AND
   Z BETWEEN @minZ AND @maxY AND
   DateTime BETWEEN @minDate AND @maxDate AND
   @i1 >0 AND
   1=1
GROUP BY hour(DateTime);
;
