#
#  --- Generate table 1 in paper PS
#

set @minX=-25;
set @maxX=-5;

set @minY=-15;
set @maxY=15;

set @minZ=-5;
set @maxZ=5;

set @minR=0;
set @maxR=25;

set @minLat=0;
set @maxLat=99;


source _tab_statistikk_region.sql;

# --- write formatted output to table; Locale fr_CH ensures XXXX,xx format
select 
   concat('%% PS   : ',@dr," Counts =",@cr," R=",@rr," X=",@xr," Y=",@yr," Z=",@zr," Lat=",@lr) as ''
;

select 
   'Plasma sheet        & X$_{GSM} <=$ -5 Re   & ' as '',
   format(@TotHr,0,'en_US') as '', 
   '     &   ' as '',
   format(100*@SiHr/@TotHr,1,'en_US') as '',
   '     &   ' as '',
#   format(@SiO,3,'en_US') as '',
#   '     &   ' as '',
   format(100*@FeHr/@TotHr,1,'en_US') as '',
#   '     &   ' as '',
#   format(@FeO,3,'en_US') as '',
   ' \\' as ''
;

