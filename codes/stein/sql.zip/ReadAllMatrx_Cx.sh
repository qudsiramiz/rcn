#!/bin/bash -f
#
#  Script to read in Cluster SiFe MATRX files into DB
#
#  Usage:
#	ReadMatrx.sh [SCID]
#
#  1) Run this fileto read ALL files.
#  2) dbquery < ingestClusterMatrx.sql
#

SC=4
#OUTFILE=/tmp/hm_c${SC}.txt
#echo "" | tr '\n' '' > $OUTFILE

for y in {2001..2019}
do 
  echo $y
  ./ReadMatrx.sh ../data/RMTRX/C${SC}_rmtrx_list_$y.dat
done


