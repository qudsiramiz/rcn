#
#  64 spin accu ~ 256 sec
#


set @minDate = '2001-06-01';
set @maxDate = '2019-12-31';
set @minCount=10.0/64.0;   #(0.15 ~ 10/64  ~ 10 counts)
set @maxCount=250;    

set @SiHr=0;
set @FeHr=0;
set @TotHr=0;
set @dummy='';
set @s=" - ";

set @dr=concat(@minDate,@s,@maxDate,",");
set @xr=concat(@minX,@s,@maxX,",");
set @yr=concat(@minY,@s,@maxY,",");
set @zr=concat(@minZ,@s,@maxZ,",");
set @rr=concat(@minR,@s,@maxR,",");
set @cr=concat(format(@minCount,2),@s,@maxCount,",");
set @lr=concat(@minLat,@s,@maxLat,",");
#
#
#
select 
   @SiHr:=256*count(*)/3600 as ''
#   format(256*sum(Si1)+sum(Si2)+sum(Si3)+sum(Si4)+sum(Si5)+sum(Si6)+sum(Si7)+sum(Si8),0) as ''
from 
  Cluster.Matrx M
where
  DateTime between @minDate and @maxDate and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
  (Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3)) between @minY and @maxY and
  (Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Si1+Si2+Si3+Si4+Si5+Si6+Si7+Si8 between @minCount and @maxCount and
  1=1
into @dummy
;

select 
   @FeHr:=256*count(*)/3600 as ''
#   format(256*sum(Fe1)+sum(Fe2)+sum(Fe3)+sum(Fe4)+sum(Fe5)+sum(Fe6)+sum(Fe7)+sum(Fe8),0) as ''
from 
  Cluster.Matrx M
where
  DateTime between @minDate and @maxDate and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
  (Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3)) between @minY and @maxY and
  (Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Fe1+Fe2+Fe3+Fe4+Fe5+Fe6+Fe7+Fe8 between @minCount and @maxCount and
  1=1
into @dummy
;

select 
   @TotHr:=256*count(*)/3600 as ''
from 
  Cluster.Matrx M
where
  DateTime between @minDate and @maxDate and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
  (Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3)) between @minY and @maxY and
  (Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) between @minZ and @maxZ and
 abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  1=1
into @dummy
;


select 
   @SiO:=sum(Si1+Si2+Si3+Si4+Si5+Si6)/sum(O2+O3+O4+O5+O6+O7) as ''
#   @SiO:=sum(Si1+Si2+Si3+Si4+Si5)/sum(H7+H8) as ''
from 
  Cluster.Matrx M
where
  DateTime between @minDate and @maxDate and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
  (Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3)) between @minY and @maxY and
  (Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Si1+Si2+Si3+Si4+Si5+Si6+Si7+Si8 between @minCount and @maxCount and
  1=1
into @dummy
;

select 
   @FeO:=sum(Fe1+Fe2+Fe3)/sum(O5+O6+O7) as ''
from 
  Cluster.Matrx M
where
  DateTime between @minDate and @maxDate and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
  (Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3)) between @minY and @maxY and
  (Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Fe1+Fe2+Fe3+Fe4+Fe5+Fe6+Fe7+Fe8 between @minCount and @maxCount and
  1=1
into @dummy
;


