#
#  --- Generate table 1 in paper: all regions combined
#
#  mysql -N to suppress headers
#
set @minX=-25;
set @maxX=25;

set @minY=-25;
set @maxY=25;

set @minZ=-25;
set @maxZ=25;

set @minR=0;
set @maxR=25;

set @minLat=0;
set @maxLat=99;

#
# ----- All regions --- 
#
#

source _tab_statistikk_region.sql;

# --- write formatted output to table; Locale fr_CH ensures XXXX,xx format
select 
   concat('%% ALL  : ',@dr," Counts =",@cr," R=",@rr," X=",@xr," Y=",@yr," Z=",@zr," Lat=",@lr) as ''
;

select 
   'Entire Cluster      & Total observation     &' as '',
   format(@TotHr,0,'en_US') as '', 
   '     &   ' as '',
   format(100*@SiHr/@TotHr,1,'en_US') as '',
   '     &   ' as '',
#   format(@SiO,3,'en_US') as '',
#   '     &   ' as '',
   format(100*@FeHr/@TotHr,1,'en_US') as '',
#   '     &   ' as '',
#   format(@FeO,3,'en_US') as '',
   ' \\' as ''
;

