#!/bin/bash -f
#
#  Script to read in Cluster SiFe MATRX files into DB
#
#  Usage:
#	ReadMatrx.sh [SCID]
#
#  1) Run this fileto read ALL files.
#  2) dbquery < ingestClusterMatrx.sql
#

FILE=$1;
SCID=$2;
OUTFILE=/tmp/hm_c4.txt
#echo "" | tr '\n' '' > $OUTFILE

/bin/sed -i 's/\r//g' $FILE


DBupdate='/usr/bin/mysql -P 3309 -h127.0.0.1 -e ' 

Num=99;	
DateTime='';
Ox="";
Hy="";
He="";
Fe="";
Si="";

while read line
do

if [[ $line =~ .*Orb.* ]] 
then
   DateTime="${line:0:4}-${line:4:2}-${line:6:2}T${line:9:2}:${line:11:2}:00"
   PosGSE="${line#*GSE=}" && PosGSE=${PosGSE%GSE*}
   GSEGSM="${line#*GSM=}"
   SCID=${line:16:1}
   Orbit="${line#*Orb=}" && Orbit=${Orbit%GSE=*}
#   Orbit=${line:22:10}
#   echo $DateTime "|" $SCID "|" $Orbit "||||" $PosGSE "|" $GSEGSM
   Num=0
else
   Num=$(( $Num + 1 ))  
   case $Num in
      1)
#  	echo "Hydrogen : " $line
        Hy=$line 
	;;
     
      2)
#	echo "Helium   : " $line
        He=$line
	;;

      3)
#	echo "Oxygen   : " $line
        Ox=$line 
	;;

      4)
#	echo "Silicon  : " $line
        Si=$line 
	;;

      5)
#	echo "Iron     : " $line
        Fe=$line
	    SQL=`echo \"${DateTime}\" $Orbit $SCID $PosGSE $GSEGSM $Hy $He $Ox $Si $Fe | tr ' ' ',' `

#	    SQL="UPDATE Cluster.Matrx SET OrbitNo=${Orbit} WHERE DateTime='${DateTime}' AND SCid=${SCID};"
        echo $SQL
         $DBupdate "insert into Cluster.Matrx values (${SQL});"
#        $DBupdate "UPDATE Cluster.Matrx SET OrbitNo=${Orbit} WHERE DateTime='${DateTime}' AND SCid=${SCID};"
	;;

      6)
	echo "Header     : " $line
	;;


   esac
fi

done < $FILE


