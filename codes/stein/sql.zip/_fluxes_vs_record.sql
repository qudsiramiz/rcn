#
# For Yama project get fluxes of Fe or Si
#
# record by record

SELECT 
   DateTime,
   @i1 as Intensity,
   @i2 as StdDev,
   SCID as SCid
FROM
   Cluster.Matrx
WHERE
   X BETWEEN @minX AND @maxX AND
   Y BETWEEN @minY AND @maxY AND
   Z BETWEEN @minZ AND @maxY AND
   DateTime BETWEEN "@minDate" AND "@maxDate" AND
   @i1 >0 AND
   1=1
;
