
select 
   @mom(Si1),@mom(Si2),@mom(Si3),@mom(Si4),@mom(Si5),@mom(Si6),@mom(Si7),@mom(Si8),
   @err(Si1),@err(Si2),@err(Si3),@err(Si4),@err(Si5),@err(Si6),@err(Si7),@err(Si8),
   count(Si1)
from 
  Cluster.Matrx M
where
  DateTime between '@minDate' and '@maxDate' and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
# --- Y can always be GSM since no limits in SW 
  Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3) between @minY and @maxY and
# -- lobe - two areas; Z can always be GSMsince nolimits in SW
#1  abs(Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) > @minZ and
#2  Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Si1+Si2+Si3+Si4+Si5+Si6+Si7+Si8 between @minCount and @maxCount and
 1=1
;

