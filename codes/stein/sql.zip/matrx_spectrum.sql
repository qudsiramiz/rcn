#
#
#

SELECT 
   mom(@i1),mom(@i2),mom(@i3),mom(@i4),mom(@i5),mom(@i6),mom(@i7),mom(@i8),
   count(@i1)
FROM
   Cluster.Matrx
WHERE
   X BETWEEN @minX AND @maxX AND
   Y BETWEEN @minY AND @maxY AND
   Z BETWEEN @minZ AND @maxY AND
   DateTime BETWEEN @minDate AND @maxDate AND
   @i1 >0 AND @i2>0 and @i3>0 AND @i4>0 AND
   1=1
;
