
select 
   @mom(Si1),@mom(Si2),@mom(Si3),@mom(Si4),@mom(Si5),@mom(Si6),@mom(Si7),@mom(Si8),
   @err(Si1),@err(Si2),@err(Si3),@err(Si4),@err(Si5),@err(Si6),@err(Si7),@err(Si8),
   @mom(Fe1),@mom(Fe2),@mom(Fe3),@mom(Fe4),@mom(Fe5),@mom(Fe6),@mom(Fe7),@mom(Fe8),
   @err(Fe1),@err(Fe2),@err(Fe3),@err(Fe4),@err(Fe5),@err(Fe6),@err(Fe7),@err(Fe8),
   count(Si1)
from 
  Cluster.Matrx M
where
  DateTime between '@minDate' and '@maxDate' and
  @R:=sqrt(X*X + Y*Y + Z*Z) between @minR and @maxR and 
  X between @minX and @maxX and
# --- Y can always be GSM since no limits in SW 
  Y*cos(GSEGSM/57.3)+Z*sin(GSEGSM/57.3) between @minY and @maxY and
# -- lobe - two areas; Z can always be GSMsince nolimits in SW
#1  abs(Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3)) > @minZ and
#2  Z*cos(GSEGSM/57.3)+Y*sin(GSEGSM/57.3) between @minZ and @maxZ and
  abs(57.3*asin(Z/sqrt(X*X+Y*Y+Z*Z))) between @minLat and @maxLat and
  Fe1+Fe2+Fe3+Fe4+Fe5+Fe6+Fe7+Fe8 between @minCount and @maxCount and
  Si1+Si2+Si3+Si4+Si5+Si6+Si7+Si8 between @minCount and @maxCount and
 1=1
;

