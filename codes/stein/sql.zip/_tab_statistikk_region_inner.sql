#
#  --- Generate table 1 in paper IMMER MSP
#


set @minX=-22;
set @maxX=22;

set @minY=-22;
set @maxY=22;

set @minZ=-22;
set @maxZ=22;

set @minR=0;
set @maxR=6.6;

set @minLat=0;
set @maxLat=99;

# ----- Inner magnetosphere  --- 

source _tab_statistikk_region.sql;


# --- write formatted output to table; Locale fr_CH ensures XXXX,xx format
select 
   concat('%% Imsp : ',@dr," Counts =",@cr," R=",@rr," X=",@xr," Y=",@yr," Z=",@zr," Lat=",@lr) as ''
;

select 
   'Inner magnetosphere & Cluster inside 6.6Re  &' as '',
   format(@TotHr,0,'en_US') as '', 
   '     &   ' as '',
   format(100*@SiHr/@TotHr,1,'en_US') as '',
   '     &   ' as '',
#   format(@SiO,3,'en_US') as '',
#   '     &   ' as '',
   format(100*@FeHr/@TotHr,1,'en_US') as '',
#   '     &   ' as '',
#   format(@FeO,3,'en_US') as '',
   ' \\' as ''
;
